# Add texture
from pxr import UsdShade, Sdf, UsdGeom
import omni
stage = omni.usd.get_context().get_stage()
terrain_mesh = stage.DefinePrim("/World/sticker/S_Barcode", "Mesh")
material_path = Sdf.Path("/World/Looks/PreviewSurfaceTexture")
material = UsdShade.Material.Get(stage, material_path)

# Create a shader for the material.
shader = UsdShade.Shader.Define(stage, material_path.AppendChild('PBRShader'))
shader.CreateIdAttr('UsdPreviewSurface')

# Create an input for the diffuse color.
diffuse_color_input = shader.CreateInput('diffuseColor', Sdf.ValueTypeNames.Color3f)

# Create a texture for the diffuse color.
texture_path = material_path
texture = UsdShade.Material.Get(stage, texture_path)

# Set the file path of the texture.
texture.CreateInput('BaseColor_Texture', Sdf.ValueTypeNames.Asset).Set("C:\Program Files\sticker\stickers\stickers\sticker_2.png")

# Connect the texture to the diffuse color input.
texture.CreateOutput('rgb', Sdf.ValueTypeNames.Float3).ConnectToSource(diffuse_color_input)

# Bind the material to the mesh.
UsdShade.MaterialBindingAPI(terrain_mesh).Bind(material)  