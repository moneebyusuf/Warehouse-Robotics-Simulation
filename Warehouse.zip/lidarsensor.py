import omni                                                     # Provides the core omniverse apis
from time import sleep 
import asyncio                                               # Used to run sample asynchronously to not block rendering thread
from omni.isaac.range_sensor import _range_sensor               # Imports the python bindings to interact with Lidar sensor
from pxr import UsdGeom, Gf, UsdPhysics, Semantics 
import threading             # pxr usd imports used to create cube

stage = omni.usd.get_context().get_stage()                      # Used to access Geometry
timeline = omni.timeline.get_timeline_interface()               # Used to interact with simulation
lidarInterface = _range_sensor.acquire_lidar_sensor_interface() # Used to interact with the LIDAR

# These commands are the Python-equivalent of the first half of this tutorial
omni.kit.commands.execute('AddPhysicsSceneCommand',stage=stage, path='/World/PhysicsScene')
lidarPath = "/LidarName"
# Create Lidar prim
result, prim = omni.kit.commands.execute(
    "RangeSensorCreateLidar",
    path=lidarPath,
    parent="/World/noob_robot",
    min_range=0.4,
    max_range=10.0,
    draw_points=True,
    draw_lines=True,
    horizontal_fov=360.0,
    vertical_fov=60.0,
    horizontal_resolution=0.4,
    vertical_resolution=0.4,
    rotation_rate=0.0,
    high_lod=False,
    yaw_offset=0.0,
    enable_semantics=True
)
UsdGeom.XformCommonAPI(prim).SetTranslate((0.0, 0.0, 0.7))

