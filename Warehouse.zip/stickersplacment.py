from omni.isaac.core.articulations import Articulation
from pxr import UsdShade, Sdf, UsdGeom
import omni
import numpy as np
import omni.isaac.core.utils.prims as prim
import json
import os
from scipy.spatial.transform import Rotation as R
import omni.isaac.core.utils.prims as prim_utils
from omni.isaac.core.prims import XFormPrim
def change_png(alias,mesh_path,mat_path) :
    stage = omni.usd.get_context().get_stage()
    terrain_mesh = stage.DefinePrim(mesh_path, "Mesh")
        # Create a material.
    material_path = Sdf.Path(mat_path)
    material = UsdShade.Material.Define(stage, material_path)

    # Create a shader for the material.
    shader = UsdShade.Shader.Define(stage, material_path.AppendChild('PBRShader'))
    shader.CreateIdAttr('UsdPreviewSurface')

    # Create an input for the diffuse color.
    diffuse_color_input = shader.CreateInput('diffuseColor', Sdf.ValueTypeNames.Color3f)

    shader.CreateInput("roughness", Sdf.ValueTypeNames.Float).Set(0.5)
    shader.CreateInput("metallic", Sdf.ValueTypeNames.Float).Set(0.0)
    # Create a texture for the diffuse color.
    # texture_path = material_path.AppendChild('diffuseTexture')
    texture_path = material_path.AppendChild('diffuseColorTex')

    texture = UsdShade.Shader.Define(stage, texture_path)
    texture.CreateIdAttr('UsdUVTexture')
    png_path=f'C:\Program Files\sticker\stickers\stickers\sticker_{alias}.png'
    # Set the file path of the texture.
    texture.CreateInput('file', Sdf.ValueTypeNames.Asset).Set(png_path)
    # texture.CreateInput('file', Sdf.ValueTypeNames.Asset).Set('/home/ahallak/Downloads/Solid_blue.png')

    # Connect the texture to the diffuse color input.
    texture.CreateOutput('rgb', Sdf.ValueTypeNames.Float3).ConnectToSource(diffuse_color_input)

    shader.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f).ConnectToSource(texture.ConnectableAPI(), 'rgb')
    material.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(), "surface")
    # Bind the material to the mesh.
    UsdShade.MaterialBindingAPI(terrain_mesh).Bind(material)

json_file_path = r"C:\Users\monee\AppData\Local\ov\pkg\isaac-sim-4.0.0\json data\labMap.json"
template_prim_path = "/World/sticker"
mm_to_m = 1 / 1000.0
with open(json_file_path, "r") as f:
    Stickers_data = json.load(f)
form_path = f"/World/Stickers"
if not prim_utils.is_prim_path_valid(form_path):
    # Create the Xform
    my_xform = XFormPrim(prim_path=form_path)
for sticker in Stickers_data.get("stickers") :
    x = sticker.get("x", 0) * mm_to_m  # Convert from mm to meters
    y = sticker.get("y", 0) * mm_to_m
    alias=sticker.get("alias",0)
    name="sticker_"+str(alias)
    copied_prim_path = form_path+"/"+name
    omni.kit.commands.execute("CopyPrims", paths_from=[template_prim_path],paths_to=[copied_prim_path], duplicate_layers=False, combine_layers=False)
    prim = Articulation(prim_path=copied_prim_path)
    prim.set_local_pose(translation=np.array([x, y, 0.0001]))
    mesh_path=copied_prim_path+"/S_Barcode"
    mat_path=copied_prim_path+"/Looks/PreviewSurfaceTexture"
    change_png(alias,mesh_path,mat_path)
