from omni.isaac.core.articulations import Articulation
import omni
import numpy as np
import omni.isaac.core.utils.prims as prim
print(position)
for i in range(11):
    omni.kit.commands.execute("CopyPrims", paths_from=["/World/Floor"],paths_to=["/World/Floor"], duplicate_layers=False, combine_layers=False)
    g=i+1
    prim_path = f"/World/Rack/floor_0{str(g)}"
    prim = Articulation(prim_path=prim_path)
    prim.set_local_pose(translation=np.array([3.72195, -1.67084, 1.0+g]))
    