from omni.isaac.core.utils.logging import log_info, log_warning, log_error

# Example usage
log_info("This is an info message.")  # Appears as informational output
log_warning("This is a warning message.")  # Appears as a warning
log_error("This is an error message.")  # Appears as an error