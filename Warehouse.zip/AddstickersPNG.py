# Add texture
from pxr import UsdShade, Sdf, UsdGeom
import omni
stage = omni.usd.get_context().get_stage()
terrain_mesh = stage.DefinePrim("/World/Cube", "Mesh")
    # Create a material.
material_path = Sdf.Path("/World/Looks/PreviewSurfaceTexture")
material = UsdShade.Material.Define(stage, material_path)

# Create a shader for the material.
shader = UsdShade.Shader.Define(stage, material_path.AppendChild('PBRShader'))
shader.CreateIdAttr('UsdPreviewSurface')

# Create an input for the diffuse color.
diffuse_color_input = shader.CreateInput('diffuseColor', Sdf.ValueTypeNames.Color3f)

shader.CreateInput("roughness", Sdf.ValueTypeNames.Float).Set(0.5)
shader.CreateInput("metallic", Sdf.ValueTypeNames.Float).Set(0.0)
# Create a texture for the diffuse color.
# texture_path = material_path.AppendChild('diffuseTexture')
texture_path = material_path.AppendChild('diffuseColorTex')

texture = UsdShade.Shader.Define(stage, texture_path)
texture.CreateIdAttr('UsdUVTexture')

# Set the file path of the texture.
texture.CreateInput('file', Sdf.ValueTypeNames.Asset).Set('C:\Program Files\sticker\stickers\stickers\sticker_13.png')
# texture.CreateInput('file', Sdf.ValueTypeNames.Asset).Set('/home/ahallak/Downloads/Solid_blue.png')

# Connect the texture to the diffuse color input.
texture.CreateOutput('rgb', Sdf.ValueTypeNames.Float3).ConnectToSource(diffuse_color_input)

shader.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f).ConnectToSource(texture.ConnectableAPI(), 'rgb')
material.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(), "surface")
# Bind the material to the mesh.
UsdShade.MaterialBindingAPI(terrain_mesh).Bind(material)