
from omni.isaac.sensor import Camera
import omni.isaac.core.utils.numpy.rotations as rot_utils
import numpy as np
import matplotlib.pyplot as plt
camera = Camera(
    prim_path="/World/rsd455/RSD455/Camera_Pseudo_Depth",
    frequency=20,
    resolution=(512, 512)
)
camera.initialize()
camera.add_motion_vectors_to_frame()
print(camera.get_current_frame())
t=camera.get_rgba()[:, :, :3]
imgplot = plt.imshow(t)
plt.savefig(r"C:\Users\monee\Downloads\gg\gg1.png")
