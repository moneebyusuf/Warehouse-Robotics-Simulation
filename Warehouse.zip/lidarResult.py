
import omni                                                     # Provides the core omniverse apis
from time import sleep 
import asyncio                                               # Used to run sample asynchronously to not block rendering thread
from omni.isaac.range_sensor import _range_sensor               # Imports the python bindings to interact with Lidar sensor
from pxr import UsdGeom, Gf, UsdPhysics, Semantics 
import threading
lidarInterface = _range_sensor.acquire_lidar_sensor_interface()
lidarPath = "/LidarName"
pointcloud = lidarInterface.get_point_cloud_data("/World/noob_robot" + lidarPath)
semantics = lidarInterface.get_semantic_data("/World/noob_robot" + lidarPath)
print("Point Cloud", pointcloud, flush=True)
print("Semantic ID", semantics, flush=True)


