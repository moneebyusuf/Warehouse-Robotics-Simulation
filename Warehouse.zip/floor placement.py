from omni.isaac.core.articulations import Articulation
import omni
import numpy as np
import omni.isaac.core.utils.prims as prim
import json
import os
from scipy.spatial.transform import Rotation as R
import omni.isaac.core.utils.prims as prim_utils
from omni.isaac.core.prims import XFormPrim
def deg2quat(x):
    if x==270 :
        return 180  
    if x==90 :
        return 0
    if x==180 :
        return 270
    if x==0 :
        return 90
# JSON file path
json_file_path = r"C:\Users\monee\AppData\Local\ov\pkg\isaac-sim-4.0.0\json data\rack_floor_heights.json"

# Template prim to copy
template_prim_path = "/World/Floor"

# Scale factor to convert mm to meters
mm_to_m = 1 / 1000.0

# Load the JSON file
with open(json_file_path, "r") as f:
    rack_sides_data = json.load(f)
form_path = f"/World/Floors"
if not prim_utils.is_prim_path_valid(form_path):
    # Create the Xform
    my_xform = XFormPrim(prim_path=form_path)
# Process each rack side
for rack_side in rack_sides_data:
    name =rack_side.get("rack_name","unknown")
    xform_path = f"{form_path}/rack_{name}"
    if not prim_utils.is_prim_path_valid(xform_path):
        # Create the Xform
        my_xform = XFormPrim(prim_path=xform_path)
    position = rack_side.get("position", {})
    x = position.get("x", 0) * mm_to_m  # Convert from mm to meters
    y = position.get("y", 0) * mm_to_m
    orien= rack_side.get("orientation", 0)
    orien1=deg2quat(orien)
    angle_radians = np.deg2rad(orien1)
    quaternion = R.from_euler('x', angle_radians).as_quat()
    for floor in rack_side.get("floors"):
        name = "floor"+floor.get("floor", "Unknown")
        height_z = floor.get("height_z", 0)
        z=height_z*mm_to_m
        copied_prim_path = xform_path+"/"+name
        omni.kit.commands.execute("CopyPrims", paths_from=[template_prim_path],paths_to=[copied_prim_path], duplicate_layers=False, combine_layers=False)
        prim = Articulation(prim_path=copied_prim_path)
        prim.set_local_pose(translation=np.array([x, y, z]),orientation=quaternion)
