
from omni.isaac.core.articulations import Articulation
from omni.physx.scripts import utils
import omni.isaac.core.utils.prims as prims_utils
import omni
import omni.kit.commands
import json
stage = omni.usd.get_context().get_stage()
joint_type="FixedJoint"
json_file_path = r"C:\Users\monee\AppData\Local\ov\pkg\isaac-sim-4.0.0\json data\rack_sides_with_names.json"
with open(json_file_path, "r") as f:
    rack_sides_data = json.load(f)
for rack_side in rack_sides_data:
    name =rack_side.get("name","unknown")
    path=f"/World/RackSides/{name}"
    to_prim=stage.GetPrimAtPath(path)
    from_prim=stage.GetPrimAtPath("/World/flat_plane")
    prim = utils.createJoint(stage, joint_type, from_prim, to_prim)
    from_prim=stage.GetPrimAtPath(path)
    associations=rack_side.get("associations",[])
    for rack in associations :
        rack_name=rack.get("rack_name","unknown")
        rack_path=f"/World/Floors/rack_{rack_name}"
        prim = prims_utils.get_prim_at_path(rack_path)
        children=prims_utils.get_prim_children(prim)
        for child in children :
            to_prim=child
            prim = utils.createJoint(stage, joint_type, from_prim, to_prim)
        
