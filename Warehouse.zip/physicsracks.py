import omni
import omni.usd
import omni.physxcommands
from omni.isaac.core.objects import DynamicCuboid
stage = omni.usd.get_context().get_stage()
prim = stage.GetPrimAtPath("/World/rack_15/floor01")

# apply rigid body API and schema
omni.kit.commands.execute("AddPhysicsComponentCommand",
                          usd_prim=prim,
                          component="PhysicsRigidBodyAPI")
omni.kit.commands.execute('AddPhysicsComponent',
                          usd_prim=prim,
                          component='PhysicsCollisionAPI')
prim1 = stage.GetPrimAtPath("/World/RackSides/L_15_R_14")

# apply rigid body API and schema
omni.kit.commands.execute("AddPhysicsComponentCommand",
                          usd_prim=prim1,
                          component="PhysicsRigidBodyAPI")
omni.kit.commands.execute('AddPhysicsComponent',
                          usd_prim=prim1,
                          component='PhysicsCollisionAPI')
attr = prim.GetAttribute("physxRigidBody:disableGravity")
omni.physxcommands.SetStaticColliderCommand(
    path=prim,
    approximationShape='none'  # Options: 'none', 'convexHull', etc.
)


print(attr)