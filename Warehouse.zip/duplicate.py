import omni
for i in range(3):
    omni.kit.commands.execute("CopyPrims", paths_from=["/World/Rack"], duplicate_layers=False, combine_layers=False)
