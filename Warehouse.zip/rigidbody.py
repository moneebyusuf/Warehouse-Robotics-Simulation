import omni
import omni.usd

stage = omni.usd.get_context().get_stage()
prim = stage.GetPrimAtPath("/World/Xform")

# apply rigid body API and schema
omni.kit.commands.execute("AddPhysicsComponentCommand",
                          usd_prim=prim,
                          component="PhysicsRigidBodyAPI")

attr = prim.GetAttribute("physxRigidBody:disableGravity")
print(attr)