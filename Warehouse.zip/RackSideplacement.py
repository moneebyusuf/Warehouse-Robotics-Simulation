from omni.isaac.core.articulations import Articulation
import omni
import numpy as np
import omni.isaac.core.utils.prims as prim
import json
import os
import omni.isaac.core.utils.prims as prim_utils
from omni.isaac.core.prims import XFormPrim
from scipy.spatial.transform import Rotation as R

def deg2quat(x):
    if x==270 :
        return 180  
    if x==90 :
        return 0
    if x==180 :
        return 270
    if x==0 :
        return 90
# JSON file path
json_file_path = r"C:\Users\monee\AppData\Local\ov\pkg\isaac-sim-4.0.0\json data\rack_sides_with_names.json"

# Template prim to copy
template_prim_path = "/World/Rackside"

# Scale factor to convert mm to meters
mm_to_m = 1 / 1000.0

# Load the JSON file
with open(json_file_path, "r") as f:
    rack_sides_data = json.load(f)

# Process each rack side
xform_path = f"/World/RackSides"
if not prim_utils.is_prim_path_valid(xform_path):
    # Create the Xform
    my_xform = XFormPrim(prim_path=xform_path)
for rack_side in rack_sides_data:
    name = rack_side.get("name", "Unknown")
    position = rack_side.get("position", {})
    x = position.get("x", 0) * mm_to_m  # Convert from mm to meters
    y = position.get("y", 0) * mm_to_m
    z = 0.0  # Default z-position
    orien= rack_side.get("associations",{})
    orien=orien[0].get("orientation",0)
    orien1=deg2quat(orien)
    angle_radians = np.deg2rad(orien1)
    quaternion = R.from_euler('x', angle_radians).as_quat()
    # Destination path for the copied rack side
    copied_prim_path = xform_path+"/"+name
    omni.kit.commands.execute("CopyPrims", paths_from=[template_prim_path],paths_to=[copied_prim_path], duplicate_layers=False, combine_layers=False)
    # Set the position of the copied rack side
    prim = Articulation(prim_path=copied_prim_path)
    prim.set_local_pose(translation=np.array([x, y, z]),orientation=quaternion)

    